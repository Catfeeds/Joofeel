<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/11/6
 * Time: 14:31
 */

namespace App\Exceptions;


class ExceptionCode
{
    const REDIRECT_TO_LOGIN = 100;
}