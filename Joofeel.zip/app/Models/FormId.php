<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/12/14
 * Time: 13:28
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class FormId extends Model
{
    public $table = 'form_id';

    public $timestamps = false;

    const NOT_USE = 0;
    const USED = 1;
}