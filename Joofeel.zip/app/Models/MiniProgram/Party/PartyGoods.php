<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/11/26
 * Time: 20:25
 */

namespace App\Models\MiniProgram\Party;


use Illuminate\Database\Eloquent\Model;

class PartyGoods extends Model
{
    protected $table = 'party_goods';

    public $timestamps = false;
}