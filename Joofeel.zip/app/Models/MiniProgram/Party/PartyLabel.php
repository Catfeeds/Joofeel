<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/12/25
 * Time: 9:15
 */

namespace App\Models\MiniProgram\Party;


use Illuminate\Database\Eloquent\Model;

class PartyLabel extends Model
{
    protected $table = 'party_label';

    public $timestamps = false;

    protected $fillable =
        [
            'party_id',
            'label_name'
        ];
}