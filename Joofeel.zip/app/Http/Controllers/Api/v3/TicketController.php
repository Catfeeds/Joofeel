<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/12/20
 * Time: 16:36
 */

namespace App\Http\Controllers\Api\v3;

use App\Http\Controllers\Controller;

class TicketController extends Controller
{
    public function get()
    {

    }
}