<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/10/30
 * Time: 10:06
 */

namespace App\Services;

use App\Models\Order\GoodsOrder;
use App\Models\Order\OrderId;
use App\Models\Party\Party;
use App\Models\Party\PartyOrder;
use App\Models\User\DeliveryAddress;
use App\Models\User\User;
use App\Models\User\UserCoupon;
use App\Utils\Common;

const dayTimeStamp = 86400;

class UserService
{
    public function get($limit)
    {
        $user = User::withCount('host')
                    ->withCount('join')
                    ->where('nickname','!=','')
                    ->get();
        return $user;
    }
}