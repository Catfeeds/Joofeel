<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/12/20
 * Time: 16:37
 */

namespace App\Services\Enter;


class TicketService
{

}