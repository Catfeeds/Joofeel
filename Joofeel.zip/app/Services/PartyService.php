<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/10/31
 * Time: 19:21
 */

namespace App\Services;


use App\Exceptions\AppException;
use App\Models\Order\OrderId;
use App\Models\Party\Message;
use App\Models\Party\Party;
use App\Models\Party\PartyGoods;
use App\Models\Party\PartyOrder;

class PartyService
{


}