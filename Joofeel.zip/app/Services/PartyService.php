<?php
/**
 * Created by PhpStorm.
 * User: locust
 * Date: 2018/10/31
 * Time: 19:21
 */

namespace App\Services;

use App\Models\Party\Party;

class PartyService
{

    public function search($content,$limit)
    {
        $data = Party::leftJoin('user as u','u.id','=','party.id')
                     ->where('u.nickname','like','%'.$content.'%')
                     ->orWhere('party.description','like','%'.$content.'%')
                     ->paginate($limit);
        return $data;
    }
}